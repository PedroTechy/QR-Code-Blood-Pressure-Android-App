package org.feup.apm.qrgen;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
  EditText heart, diast, systo;
  TextView tvError;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);

    // Define ActionBar object
    ActionBar actionBar;
    actionBar = getSupportActionBar();
    ColorDrawable colorDrawable
            = new ColorDrawable(Color.parseColor("#2196F3"));
    // Set BackgroundDrawable
    actionBar.setBackgroundDrawable(colorDrawable);
    setContentView(R.layout.activity_main);
  
    heart = findViewById(R.id.edt_heart);
    diast = findViewById(R.id.edt_diast);
    systo = findViewById(R.id.edt_systo);
    tvError = findViewById(R.id.tv_error);
    findViewById(R.id.bt_generate).setOnClickListener((vw)->generateQR());
  }

  void generateQR() {
    int hr, dv, sv;
    Intent qrActivity;

    tvError.setText(R.string.tv_empty);
    String heart_rate = heart.getText().toString();
    String diast_value = diast.getText().toString();
    String systo_value = systo.getText().toString();

    try {
      hr = Integer.parseInt(heart_rate);
    }
    catch (Exception e) {
      tvError.setText(R.string.tv_error_nr);
      return;
    }

    try {
      dv = Integer.parseInt(diast_value);
    }
    catch (Exception e) {
      tvError.setText(R.string.tv_error_nr);
      return;
    }

    try {
      sv = Integer.parseInt(systo_value);
    }
    catch (Exception e) {
      tvError.setText(R.string.tv_error_nr);
      return;
    }


    qrActivity = new Intent(this, QRActivity.class);
    qrActivity.putExtra("hr_values", hr);
    qrActivity.putExtra("dv_values", dv);
    qrActivity.putExtra("sv_values", sv);
    startActivity(qrActivity);
  }
}