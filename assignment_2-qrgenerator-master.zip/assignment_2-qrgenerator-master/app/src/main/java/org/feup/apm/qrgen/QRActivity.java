package org.feup.apm.qrgen;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.sql.Timestamp;
import java.util.Hashtable;

public class QRActivity extends AppCompatActivity {
  private final String ISO_SET = "ISO-8859-1";
  private final static int IMAGE_SIZE=600;
  TextView tvResult;
  ImageView qrCode;
  int hr, dv, sv;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_qractivity);
    ActionBar actionBar;
    actionBar = getSupportActionBar();

    // Define ColorDrawable object and parse color
    // using parseColor method
    // with color hash code as its parameter
    ColorDrawable colorDrawable
            = new ColorDrawable(Color.parseColor("#2196F3"));

    // Set BackgroundDrawable
    actionBar.setBackgroundDrawable(colorDrawable);
    tvResult = findViewById(R.id.tv_result);
    qrCode = findViewById(R.id.im_qr);
    hr = getIntent().getIntExtra("hr_values", 1);
    dv = getIntent().getIntExtra("dv_values", 1);
    sv = getIntent().getIntExtra("sv_values", 1);
    byte[] values = generateValues(hr,dv,sv);
    String result = valuesToString(values);
    new Thread(new convertToQR(values)).start();
    tvResult.setText(result);
  }

  byte[] generateValues(int hr, int dv, int sv) {
    int k;
   // ByteBuffer bf = ByteBuffer.allocate(8+ 3*4);     // time stamp (long so 8 bytes) +  3 (as we have hr, dv, sv) * 4 (as our values are int, so 4bytes)
    ByteBuffer bf = ByteBuffer.allocate(64);     // time stamp (long so 8 bytes) +  3 (as we have hr, dv, sv) * 4 (as our values are int, so 4bytes)

    long time = System.currentTimeMillis(); //time stamp, will be needed so wont change it
    SecureRandom sr = new SecureRandom();
    bf.putLong(time); //add time stamp
    bf.putInt(dv);    //add diast value
    bf.putInt(sv);    //add systolic value
    bf.putInt(hr);    //add hear rate value

    return bf.array();  //this is the array that must contain the numbers/info to incript, in this we need the time, dv, sv and hr
  }

  String valuesToString(byte[] values) { //used to print out
    StringBuilder sb = new StringBuilder();
    int k, hr, dv, sv;
    Timestamp ts;

    ByteBuffer bf = ByteBuffer.wrap(values);

    ts = new Timestamp(bf.getLong());  //fetching the values from the array in the right order
    dv = bf.getInt();
    sv = bf.getInt();
    hr = bf.getInt();


    sb.append("Time: ");
    sb.append(ts.toString());

    sb.append("\nDiastolic Value (cmHg): ");
    sb.append(dv);
    sb.append("\nSystolic Value (cmHg): ");
    sb.append(sv);
    sb.append("\nHeart Rate (beats per minute) : ");
    sb.append(hr);

    return sb.toString();
  }

  String valuesToFetch(byte[] values) { //used to be passed out in the str that is incripted in the QR code
    StringBuilder sb = new StringBuilder();
    int k, hr, dv, sv;
    Timestamp ts;

    ByteBuffer bf = ByteBuffer.wrap(values);

    ts = new Timestamp(bf.getLong());  //fetching the values from the array in the right order
    dv = bf.getInt();
    sv = bf.getInt();
    hr = bf.getInt();

    sb.append(ts.toString()); //i will separate the string using ; so that in the qr code reader we know how to fetch all the info
    sb.append(";");
    sb.append(dv);
    sb.append(";");
    sb.append(sv);
    sb.append(";");
    sb.append(hr);
    sb.append(";");
    return sb.toString();
  }

  Bitmap encodeAsBitmap(byte[] content) {
    BitMatrix result;
    Hashtable<EncodeHintType, String> hints = new Hashtable<>();
    hints.put(EncodeHintType.CHARACTER_SET, ISO_SET);
   // String str = valuesToString(content);
    String str = valuesToFetch(content);

    try {
      result = new MultiFormatWriter().encode(str, BarcodeFormat.QR_CODE, IMAGE_SIZE, IMAGE_SIZE, hints);
    }
    catch (Exception exc) {
      runOnUiThread(()->tvResult.setText(exc.getMessage()));
      return null;
    }
    int w = result.getWidth();
    int h = result.getHeight();
    int[] pixels = new int[w * h];
    for (int line = 0; line < h; line++) {
      int offset = line * w;
      for (int col = 0; col < w; col++) {
        pixels[offset + col] = result.get(col, line) ? getResources().getColor(R.color.black):getResources().getColor(R.color.white);
      }
    }
    Bitmap bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
    bitmap.setPixels(pixels, 0, w, 0, 0, w, h);
    return bitmap;
  }

  // nested class to implement a thread to create a QRcode as a Bitmap
  // it can take a while to do this processing

  class convertToQR implements Runnable {
    byte[] content;

    convertToQR(byte[] value) {

      content = value;
      tvResult.setText("");
    }

    @Override
    public void run() {
      final Bitmap bitmap;

      bitmap = encodeAsBitmap(content);
      runOnUiThread(()->qrCode.setImageBitmap(bitmap));
    }
  }
}