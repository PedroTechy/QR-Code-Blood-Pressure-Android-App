package com.example.qrscaner;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AbsListView;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class PatientMenu extends AppCompatActivity {


    RecyclerView recyclerView;
    FloatingActionButton addButton;

    MyDataBaseHelper myDB;
    ArrayList<String> patient_id, patient_name, patient_contact, patient_health_number;
    CustomAdapterPatients customAdapterPatients;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_menu);
        // Define ActionBar object
        ActionBar actionBar;
        actionBar = getSupportActionBar();

        // Define ColorDrawable object and parse color
        // using parseColor method
        // with color hash code as its parameter
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#2196F3"));

        // Set BackgroundDrawable
        actionBar.setBackgroundDrawable(colorDrawable);

        recyclerView = findViewById(R.id.recyclerView);
        addButton = findViewById(R.id.addPatientButton);

        addButton.setOnClickListener(new View.OnClickListener() { //this is to open the add activity not to directly add a patient
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(PatientMenu.this, AddPatient.class);
                startActivity(intent);


            }
        });
        myDB = new MyDataBaseHelper(PatientMenu.this);
        patient_id = new ArrayList<> (); //initialize the arrays
        patient_name = new ArrayList<> (); //initialize the arrays
        patient_contact = new ArrayList<> (); //initialize the arrays
        patient_health_number = new ArrayList<> (); //initialize the arrays

        storePatientsInArrays(); //call the function to get the arrays so that we can update our patients and display them

        //this line fecth the values from the database and then we can "adapt" the recycler view with them
        customAdapterPatients  = new CustomAdapterPatients( PatientMenu.this,patient_id, patient_name, patient_contact, patient_health_number);
        recyclerView.setAdapter(customAdapterPatients);
        recyclerView.setLayoutManager(new LinearLayoutManager(PatientMenu.this));

    }

    void storePatientsInArrays(){
        Cursor cursor = myDB.readAllData();
        if(cursor.getCount() == 0){
            Toast.makeText(this, "No patients in database", Toast.LENGTH_SHORT).show();
        }else{
            Log.d("testando2",String.valueOf( cursor.getCount() ));
            while(cursor.moveToNext()){
                patient_id.add(cursor.getString(0)); //get the 1 column (index 0 cuz its starts in 0)
                patient_name.add(cursor.getString(1)); //get the 2 column
                patient_contact.add(cursor.getString(2)); //get the 3 column
                patient_health_number.add(cursor.getString(3)); //get the 4 column and so one

            }
        }

    }


}
