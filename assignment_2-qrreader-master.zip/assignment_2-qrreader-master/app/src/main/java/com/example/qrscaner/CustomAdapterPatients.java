package com.example.qrscaner;

import android.content.Context;
import android.content.Intent;
import android.icu.text.Transliterator;
import android.text.style.UpdateAppearance;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapterPatients extends RecyclerView.Adapter<CustomAdapterPatients.MyViewHolder>{
    private Context context;


    private ArrayList   patient_id, patient_name, patient_contact, patient_health_number;

    //intialize the constructor
    CustomAdapterPatients(Context context, ArrayList  patient_id, ArrayList patient_name, ArrayList patient_contact, ArrayList patient_health_number){
        this.context = context;
        this.patient_name = patient_name;
        this.patient_contact = patient_contact;
        this.patient_id = patient_id;
        this.patient_health_number = patient_health_number;

    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder,  final int position) {


        holder.patient_id_txt.setText(String.valueOf(patient_id.get(position)));
        holder.patient_name_txt.setText(String.valueOf(patient_name.get(position)));
        holder.patient_contact_txt.setText(String.valueOf(patient_contact.get(position)));
        holder.patient_health_number_txt.setText(String.valueOf(patient_health_number.get(position)));

        holder.mainRowLayout.setOnClickListener(new View.OnClickListener() {
            int mLastPosition = holder.getAdapterPosition();
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, PatientMeasures.class);
                intent.putExtra("name", String.valueOf(patient_name.get(mLastPosition)));
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {

        return patient_id.size(); //to get the number of patients in database
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView patient_id_txt, patient_name_txt, patient_contact_txt, patient_health_number_txt;
        LinearLayout mainRowLayout;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            patient_contact_txt = itemView.findViewById(R.id.row_patient_contact);
            patient_id_txt = itemView.findViewById(R.id.row_patient_id);
            patient_health_number_txt = itemView.findViewById(R.id.row_patient_health_number);
            patient_name_txt = itemView.findViewById(R.id.row_patient_name);
            mainRowLayout = itemView.findViewById(R.id.mainRowLayout);

        }
    }
}
