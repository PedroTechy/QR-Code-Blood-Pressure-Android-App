package com.example.qrscaner;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class AddPatient extends AppCompatActivity {

    EditText name_input, contact_input, healthNumber_input;
    Button addPatient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_patient);
        // Define ActionBar object
        ActionBar actionBar;
        actionBar = getSupportActionBar();

        // Define ColorDrawable object and parse color
        // using parseColor method
        // with color hash code as its parameter
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#2196F3"));

        // Set BackgroundDrawable
        actionBar.setBackgroundDrawable(colorDrawable);

        addPatient = findViewById(R.id.addPatient_);
        name_input = findViewById(R.id.name_input);
        contact_input = findViewById(R.id.contact_input);
        healthNumber_input = findViewById(R.id.healthNumber_input);

        addPatient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 MyDataBaseHelper myDB = new MyDataBaseHelper(AddPatient.this);
                myDB.addPatient(name_input.getText().toString().trim(),
                        Integer.valueOf(contact_input.getText().toString().trim()),
                        Integer.valueOf(healthNumber_input.getText().toString().trim()));
            }
        });
     }
}