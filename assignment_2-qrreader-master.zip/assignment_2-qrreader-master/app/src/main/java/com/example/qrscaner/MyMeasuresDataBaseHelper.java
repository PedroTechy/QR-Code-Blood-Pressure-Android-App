package com.example.qrscaner;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MyMeasuresDataBaseHelper extends SQLiteOpenHelper {

    private Context context;
    public static final String dataBaseName = "Measures.db";
    public static final String TABLE_NAME = "my_measures";
    public static final String COLUMN_TIME = "measure_date";
    public static final String COLUMN_PATIENT_NAME = "mearure_patiente_name";
    public static final String COLUMN_DIASTOLIC = "mearure_diastolic";
    public static final String COLUMN_SYSTOLIC = "measure_systolic";
    public static final String COLUMN_PULSE = "measure_pulse";
    public static int  dataBaseVersion = 1;


    public MyMeasuresDataBaseHelper(@Nullable Context context) {
        super(context, dataBaseName, null,  dataBaseVersion );
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String query =  "CREATE TABLE " + TABLE_NAME +
                " (" + COLUMN_TIME + " TEXT, " +
                COLUMN_PATIENT_NAME + " TEXT, " +
                COLUMN_DIASTOLIC + " INTEGER, " +
                COLUMN_SYSTOLIC + " INTEGER, " +
                COLUMN_PULSE+ " INTEGER);";

        db.execSQL(query);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

        db.execSQL("DROP TABLE  IF EXISTS " + TABLE_NAME); //if this database table already exist in the database file of this android app, then drop it and add to existing one
        onCreate(db);

    }

    void addMeasure(String time, String patientName, int disastolic, int systolic, int pulse ){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_TIME, time );
        cv.put(COLUMN_PATIENT_NAME, patientName);
        cv.put(COLUMN_DIASTOLIC,disastolic);
        cv.put(COLUMN_SYSTOLIC,systolic);
        cv.put(COLUMN_PULSE,pulse);
        long result = db.insert(TABLE_NAME, null, cv); //to see if we were able to insert or not the patient in the data base

        if(result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(context, "Measure added with sucess", Toast.LENGTH_SHORT).show();

        }

    }

    public Cursor getByName(String name) {

        String[] args={name};

        return(getReadableDatabase().rawQuery("SELECT measure_date, mearure_diastolic, measure_systolic, measure_pulse FROM my_measures WHERE mearure_patiente_name=?", args));

    }





}
