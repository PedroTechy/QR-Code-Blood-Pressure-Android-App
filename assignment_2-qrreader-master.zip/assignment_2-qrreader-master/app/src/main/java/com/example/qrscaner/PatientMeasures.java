package com.example.qrscaner;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.GridLabelRenderer;
import com.jjoe64.graphview.LegendRenderer;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.nio.ByteBuffer;
import java.sql.Timestamp;
import java.util.ArrayList;

public class PatientMeasures extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    EditText time, distolic, systolic, pulse;
    Button readQR, plotButton;
    GraphView graphView;
    MyMeasuresDataBaseHelper myDB_m;
    ArrayList<String> measure_time, measure_diastolic,measure_systolic, measure_pulse;
    ArrayList<String> values = new ArrayList<String>(); //will be used to store the qr values
    String name, n_points;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_measures);
        // Define ActionBar object
        ActionBar actionBar;
        actionBar = getSupportActionBar();

        // Define ColorDrawable object and parse color
        // using parseColor method
        // with color hash code as its parameter
        ColorDrawable colorDrawable
                = new ColorDrawable(Color.parseColor("#2196F3"));
        // Set BackgroundDrawable
        actionBar.setBackgroundDrawable(colorDrawable);

        //Setting up the spinners for the source and target quantities
        Spinner spinner = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.choose_number_points, android.R.layout.simple_spinner_item); //this array adapter works as the units saver
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter); //now we set the first adapter to the first
        spinner.setOnItemSelectedListener(this);
        n_points = spinner.getSelectedItem().toString();


        name = getIntent().getStringExtra("name");
        time = findViewById(R.id.time);
        plotButton = findViewById((R.id.plotButton));
        readQR = findViewById(R.id.addMeasure2);
        graphView = findViewById(R.id.graphView);
        myDB_m = new MyMeasuresDataBaseHelper(this);
        measure_time = new ArrayList<> (); //initialize the arrays
        measure_diastolic = new ArrayList<> (); //initialize the arrays
        measure_systolic = new ArrayList<> (); //initialize the arrays
        measure_pulse = new ArrayList<> (); //initialize the arrays
        name = getIntent().getStringExtra("name");
        if (name != null)
            getMeasuresByName();



        double max_x = measure_time.size()+1; // or max(datapoints.x)
        graphView.getViewport().setXAxisBoundsManual(true);
        graphView.getViewport().setMaxX(max_x);
        GridLabelRenderer gridLabel = graphView.getGridLabelRenderer();
        gridLabel.setHorizontalAxisTitle("Index");
        gridLabel.setVerticalAxisTitle("Pressure (cmHg)");

       readQR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IntentIntegrator intentIntegrator = new IntentIntegrator(PatientMeasures.this);
                //set prompt text
                intentIntegrator.setPrompt("For flash use volume key");
                intentIntegrator.setBeepEnabled(true);
                intentIntegrator.setOrientationLocked(true);
                intentIntegrator.setCaptureActivity(Capture.class);
                intentIntegrator.initiateScan();
            }
        });


       plotButton.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               String n_points = spinner.getSelectedItem().toString();
               graphView.removeAllSeries();
               String title = "Diastolic and Systolic Values - " + n_points;
               graphView.setTitle(title);
               graphView.getLegendRenderer().setVisible(true);
               graphView.getLegendRenderer().setAlign(LegendRenderer.LegendAlign.TOP);
               plotGraph(0, n_points);
               plotGraph(1, n_points);

           }
       });
    }


    void plotGraph(int measure, String n_points){

        if(measure == 1){ //lets make 1 the diastolic values and 0 the systolic ones, this way we can change the plot color
            int color = Color.parseColor("#2196F3");
            LineGraphSeries<DataPoint> diastolicPoints = getSerials(color, measure_diastolic, measure_time, n_points);
            diastolicPoints.setTitle("Diastolic Values");
            graphView.addSeries(diastolicPoints);
        }

        if(measure == 0){
            int color = Color.parseColor("#31A545"); //this is for read
            LineGraphSeries<DataPoint> systolicPoints = getSerials(color, measure_systolic, measure_time, n_points);
            systolicPoints.setTitle("Systolic Values");
            graphView.addSeries(systolicPoints);
        }
    }

    public LineGraphSeries<DataPoint> getSerials(int color,ArrayList<String> measureArray,ArrayList<String> measuretime,String n_points) {
        LineGraphSeries<DataPoint> series = new LineGraphSeries<>();
        series.setColor(color); //this can change
        series.setDrawDataPoints(true);
        series.setDataPointsRadius(6);

        Timestamp time= new Timestamp(System.currentTimeMillis());
        String times = time.toString();

        ArrayList<String> data_time_split = new ArrayList<String>(); // separar data do tempo
        ArrayList<String> data_split = new ArrayList<String>(); // separar as varias datas ( dias/mês/ano)

        data_time_array(times, data_time_split);

        String data = data_time_split.get(0);
        data(data,data_split);

        int year= Integer.parseInt(data_split.get(0));
        int mounth=Integer.parseInt(data_split.get(1));
        int day =Integer.parseInt(data_split.get(2));

        if(n_points.equals("All")) {

            for (int i = 0; i < measureArray.size(); i++) { //loop the arrays, choose this but can be anyone

                try {
                    int value = Integer.parseInt(measureArray.get(i));
                    series.appendData(new DataPoint(i + 1, value), false, 100);

                } catch (NumberFormatException formatException) {
                    System.out.println("Oops, that's not a number");
                }
            }
        }
        else if (n_points.equals("Last Day")){
            for (int i = 0; i < measuretime.size(); i++) {
                String a = measuretime.get(i); // vou buscar cada um dos valores do measure time

                ArrayList<String> data_time_measuretimesplit = new ArrayList<String>(); // separar data do tempo
                ArrayList<String> data_measuretimesplit = new ArrayList<String>(); // separar as varias datas ( dias/mês/ano)
                data_time_array(a, data_time_measuretimesplit);
                String data_measuretime = data_time_measuretimesplit.get(0);
                data(data_measuretime, data_measuretimesplit);
                int mounth_of_a = Integer.parseInt(data_measuretimesplit.get(1));
                int day_of_a =  Integer.parseInt(data_measuretimesplit.get(2));

                if (mounth_of_a == mounth && day_of_a == day) {
                    int value = Integer.parseInt(measureArray.get(i));
                    series.appendData(new DataPoint(i + 1, value), false, 100);
                }
            }
        }
        else if (n_points.equals("Last Mounth")){

                for (int i = 0; i < measuretime.size(); i++) {
                    String a = measuretime.get(i); // vou buscar cada um dos valores do measure time

                    ArrayList<String> data_time_measuretimesplit = new ArrayList<String>(); // separar data do tempo
                    ArrayList<String> data_measuretimesplit = new ArrayList<String>(); // separar as varias datas ( dias/mês/ano)
                    data_time_array(a, data_time_measuretimesplit);
                    String data_measuretime = data_time_measuretimesplit.get(0);
                    data(data_measuretime, data_measuretimesplit);
                    int mounth_of_a = Integer.parseInt(data_measuretimesplit.get(1));
                    int day_of_a =  Integer.parseInt(data_measuretimesplit.get(2));

                    if (mounth_of_a ==mounth && day_of_a < day) {
                        int value = Integer.parseInt(measureArray.get(i));
                        series.appendData(new DataPoint(i + 1, value), false, 100);
                    }
                }
            }

        else if (n_points.equals("Last Year")){
            for (int i = 0; i < measuretime.size(); i++) {
                String a = measuretime.get(i); // vou buscar cada um dos valores do measure time
                ArrayList<String> data_time_measuretimesplit = new ArrayList<String>(); // separar data do tempo
                ArrayList<String> data_measuretimesplit = new ArrayList<String>(); // separar as varias datas ( dias/mês/ano)
                data_time_array(a, data_time_measuretimesplit);

                String data_measuretime = data_time_split.get(0);
                data(data_measuretime, data_measuretimesplit);
                int year_of_a = Integer.parseInt(data_split.get(0));

                if (year_of_a == year) {
                    int value = Integer.parseInt(measureArray.get(i));
                    series.appendData(new DataPoint(i + 1, value), false, 100);
                }
            }

        }
        double max_x = series.getHighestValueX()+1; // or max(datapoints.x)
        double min_x = series.getLowestValueX()-1;
        graphView.getViewport().setXAxisBoundsManual(true);
        graphView.getViewport().setMaxX(max_x);
        graphView.getViewport().setMinX(min_x);
       return series;
    }

    void data_time_array(String strValues,ArrayList<String> data_time) {
        int i, k;
        i = 0;
        for (k = 0; k < strValues.length(); k++) {
            if (strValues.charAt(k) == ' ') {
                String val = strValues.substring(i, k);
                i = k + 1;
                data_time.add(val);
            }
        }
    }

    void data(String strValues,ArrayList<String> data) {
        int i, k;
        i = 0;
        for (k = 0; k < strValues.length(); k++) {
            if (strValues.charAt(k) == '-') {
                String val = strValues.substring(i, k);
                i = k + 1;
                data.add(val);
            }
        }
        String val = strValues.substring(8, 10);
        data.add(val);
    }


    void valuesArray(String strValues){ //to decode the qr values
        int i, k;
        i = 0;
        for(k =0; k < strValues.length(); k++){
            if(strValues.charAt(k) == ';'){
                String val = strValues.substring(i,k);
                i = k+1;
                values.add(val);
            }
        }
    }

    void getMeasuresByName() { //sql query to get the patients measures

        Cursor cursor = myDB_m.getByName(name);

        if (cursor.getCount() == 0) {
            Toast.makeText(this, "No  measures in this patient database", Toast.LENGTH_SHORT).show();

        } else {
            while (cursor.moveToNext()) {
                cursor.getColumnName(0);
                measure_time.add(cursor.getString(0)); //get the 1 column (index 0 cuz its starts in 0)
                measure_diastolic.add(cursor.getString(1)); //get the 2 column
                measure_systolic.add(cursor.getString(2)); //get the 3 column
                measure_pulse.add(cursor.getString(3)); //get the 4 column and so one

            }
        }
    }

    void setColor(int diastolic, int systolic, TextView diastolicTextView, TextView systolicTextView){
        //set diastolic background color
        if (diastolic >= 90 ){
            diastolicTextView.setTextColor(Color.RED);
        } else if (diastolic >= 80 && diastolic <= 89){
            diastolicTextView.setTextColor(Color.parseColor("#FFC107"));
        } else {
            diastolicTextView.setTextColor(Color.GREEN);}

        //set systolic background color

        if (systolic >= 140 ){
            systolicTextView.setTextColor(Color.RED);
        } else if (systolic >= 120 && systolic <= 139){
            systolicTextView.setTextColor(Color.parseColor("#FFC107"));
        } else {
            systolicTextView.setTextColor(Color.GREEN);}
    }



    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) { //qr code intent

        String strValues = "";

        super.onActivityResult(requestCode, resultCode, data);

        IntentResult intentResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);

        if(intentResult.getContents() != null) {

            TextView diastolicTextView = findViewById(R.id.diastolicValue);
            TextView systolicTextView = findViewById(R.id.systolicValue);
            TextView heartrateTextView = findViewById(R.id.HeartrateValue);

            AlertDialog.Builder builder = new AlertDialog.Builder(PatientMeasures.this);
            builder.setTitle("Result");
            strValues = intentResult.getContents();
            builder.setMessage(strValues);
            valuesArray(strValues);

            //values from the qr code
            String time = values.get(0);
            String diastolic = values.get(1);
            String systolic = values.get(2);
            String pulse = values.get(3);

            String strd = "Diastolic Value (cmHg): " + diastolic;
            String strs = "Systolic Value (cmHg): " + systolic;
            String strh = "Hearth rate (bpm): " + pulse;

            //set the values of the textviews
            diastolicTextView.setText(strd);
            systolicTextView.setText(strs);
            heartrateTextView.setText(strh);

            Log.d("tou", diastolic);
            Log.d("tou2", systolic);
            Log.d("tou3", pulse);

            setColor( Integer.parseInt(diastolic) , Integer.parseInt(systolic), diastolicTextView, systolicTextView );

            MyMeasuresDataBaseHelper myDB = new MyMeasuresDataBaseHelper(PatientMeasures.this);
            myDB.addMeasure( time,
                    name.trim(),
                    Integer.valueOf(diastolic),
                    Integer.valueOf(systolic),
                    Integer.valueOf(pulse));

            builder.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });
            builder.show();
        }else{
            //when result content is null
            Toast.makeText(getApplicationContext(), "Try again", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        ((TextView) adapterView.getChildAt(0)).setTextSize(20);
        String text = adapterView.getItemAtPosition(i).toString(); //we take the item in position "i" and convert to a string, so basicaly Im taking the unit name
        //Toast.makeText(adapterView.getContext(), text, Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}

