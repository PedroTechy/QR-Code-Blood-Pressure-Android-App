package com.example.qrscaner;

import com.journeyapps.barcodescanner.CaptureActivity; //activity from the implementation package


public class Capture  extends CaptureActivity {
}
